new Cleave('.cc', {
    creditCard: true

});